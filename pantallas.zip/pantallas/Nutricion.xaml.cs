using Microsoft.Maui.Controls;

namespace pantallas
{
    public partial class Nutricion : ContentPage
    {
        public Nutricion()
        {
            InitializeComponent();
        }

        private void OnDashboardClicked(object sender, EventArgs e)
        {
        }

        private void OnEntrenamientoClicked(object sender, EventArgs e)
        { 
        }

        private void OnNutricionClicked(object sender, EventArgs e)
        {
        }

        private void OnChatClicked(object sender, EventArgs e)
        {
        }
    }
}