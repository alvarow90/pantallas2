using Microsoft.Maui.Controls;

namespace pantallas
{
    public partial class Chat : ContentPage
    {
        public Chat()
        {
            InitializeComponent();
        }

        private void OnChatNutriologo(object sender, EventArgs e)
        {
            DisplayAlert("Chat", "Iniciando chat con el Nutri�logo", "OK");
        }

        private void OnChatEntrenador(object sender, EventArgs e)
        {
            DisplayAlert("Chat", "Iniciando chat con el Entrenador", "OK");
        }

        private void OnSendMessage(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(ChatEntry.Text))
            {
                ChatMessages.ItemsSource = new List<object>
                {
                    new { Message = ChatEntry.Text }
                };
                ChatEntry.Text = "";
            }
        }
    }
}
