namespace pantallas;

public partial class DS : ContentPage
{
	public DS()
	{
		InitializeComponent();
	}
}